# POC Starter Kit — Delivery Management Platform

## Quick Start

### Option 1: Web UI (Recommended)

1. **Set up Python environment and install backend dependencies:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. **Start the FastAPI backend:**
```bash
cd /workspaces/Delivery-Management-Platform
uvicorn src.app:app --reload --port 8000
```

3. **In a new terminal, set up and start the React frontend:**
```bash
cd frontend
npm install
npm start
```

The React app will open at `http://localhost:3000` and automatically connect to the backend at `http://localhost:8000`.

### Option 2: Command Line

1. **Create a Python venv and install dependencies:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. **Run the POC using the bundled sample data:**
```bash
python3 src/run_poc.py --config config/sample_project.yaml --data sample_data/sample_jira.json --out outputs
```

3. **Or start the API and use curl/Postman:**
```bash
uvicorn src.app:app --reload --port 8000

# Then in another terminal:
curl -X POST http://localhost:8000/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "data_source": "sample",
    "generate_excel": true,
    "generate_pptx": true,
    "generate_csv": true
  }'
```

## What This Generates

- **Excel workbook** - `outputs/report_metrics.xlsx` - Complete metrics dashboard
- **PPTX deck** - `outputs/report_deck.pptx` - Executive presentation with charts
- **Normalized CSV** - `outputs/issues_normalized.csv` - Issue data for further analysis

## Features

### Web UI
- ✨ Interactive form to configure POC runs
- 📊 Select which outputs to generate (Excel, PowerPoint, CSV)
- 🔄 Real-time processing status
- 📈 Results dashboard with metrics, risks, and file downloads
- 📱 Responsive design for mobile and desktop

### Backend API
- Clean REST API for programmatic access
- Selective output generation (no need to generate all files every time)
- Health check endpoint
- File download endpoints
- CORS support for frontend integration

## Configuration

### Project Settings
Edit `config/sample_project.yaml` to customize:
- Project name and Jira project key
- Risk thresholds (blocker days, test coverage)
- Sprints and epics

### Data Sources
- **Sample JSON** - Uses bundled `sample_data/sample_jira.json`
- **Live Jira** - Fetches data directly from Jira (requires API token)

## Security & Credentials

- **Do NOT commit secrets** to the repository
- Use environment variables or a local `.env` file (which is gitignored)

### Setup credentials:

**Option A: Environment Variables (Recommended)**
```bash
export JIRA_BASE_URL="https://your-company.atlassian.net"
export JIRA_USER="your.email@example.com"
export JIRA_API_TOKEN="your_api_token_here"
```

**Option B: Local .env File**
```bash
cp .env.example .env
# Edit .env with your values
```

Then run with Jira data source:
```bash
python3 src/run_poc.py --config config/sample_project.yaml --data jira --out outputs
```

## Project Structure

```
.
├── frontend/                    # React UI
│   ├── public/
│   ├── src/
│   │   ├── components/         # React components
│   │   ├── App.js
│   │   └── index.js
│   └── package.json
├── src/
│   ├── app.py                  # FastAPI backend
│   ├── poc_core.py             # Core logic
│   ├── jira_connector.py       # Jira integration
│   └── run_poc.py              # CLI entry point
├── config/                      # Configuration files
├── sample_data/                 # Sample Jira data
├── outputs/                     # Generated reports
└── requirements.txt             # Python dependencies
```

## Next Steps

1. **Customize Risk Rules** - Adjust `config/sample_project.yaml` thresholds
2. **Integrate Real Jira** - Set up Jira credentials and test live data fetching
3. **Deploy** - Build the React app and deploy with the FastAPI backend
4. **Extend** - Add custom metrics, risk evaluations, or report layouts

## Troubleshooting

### Frontend won't connect to backend
- Ensure backend is running on port 8000
- Check CORS is enabled in `src/app.py`
- Verify proxy setting in `frontend/package.json`

### Jira connection fails
- Verify credentials are set correctly
- Check `JIRA_BASE_URL` format (should include https://)
- Ensure API token has required permissions

### Files not generated
- Check output directory exists and is writable
- Verify config file path is correct
- Check backend logs for specific errors


