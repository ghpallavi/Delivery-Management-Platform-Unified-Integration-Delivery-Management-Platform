#!/bin/bash

# Delivery Management Platform - Start Both Frontend and Backend

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Delivery Management Platform${NC}"
echo -e "${BLUE}Starting Backend & Frontend${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Python venv exists
if [ ! -d ".venv" ]; then
    echo -e "${BLUE}Creating Python virtual environment...${NC}"
    python3 -m venv .venv
fi

# Activate venv
echo -e "${BLUE}Activating Python virtual environment...${NC}"
source .venv/bin/activate

# Install Python dependencies
echo -e "${BLUE}Installing Python dependencies...${NC}"
pip install -r requirements.txt > /dev/null 2>&1

# Start backend in background
echo -e "${GREEN}✓ Starting FastAPI backend on http://localhost:8000${NC}"
cd /workspaces/Delivery-Management-Platform
uvicorn src.app:app --reload --port 8000 > /tmp/backend.log 2>&1 &
BACKEND_PID=$!
echo "Backend PID: $BACKEND_PID"
sleep 3

# Check if backend started successfully
if ! kill -0 $BACKEND_PID 2>/dev/null; then
    echo -e "${RED}✗ Backend failed to start. Check /tmp/backend.log${NC}"
    exit 1
fi

# Start frontend
echo -e "${GREEN}✓ Starting React frontend on http://localhost:3000${NC}"
cd /workspaces/Delivery-Management-Platform/frontend

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo -e "${BLUE}Installing frontend dependencies...${NC}"
    npm install > /dev/null 2>&1
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}✓ Both services are running!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "Frontend: ${BLUE}http://localhost:3000${NC}"
echo -e "Backend:  ${BLUE}http://localhost:8000${NC}"
echo ""
echo "Press Ctrl+C to stop both services"
echo ""

# Start frontend in foreground
npm start

# Cleanup on exit
trap "kill $BACKEND_PID 2>/dev/null || true" EXIT
