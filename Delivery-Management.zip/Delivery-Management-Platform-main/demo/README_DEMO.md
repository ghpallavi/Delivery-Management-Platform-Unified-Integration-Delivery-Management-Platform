Demo steps — POC Automated Weekly Delivery Review

1. Install dependencies (see README_POC.md)
2. Run the POC locally and inspect `outputs/` for generated artifacts

Commands:

```bash
python3 src/run_poc.py --config config/sample_project.yaml --data sample_data/sample_jira.json --out outputs
ls -l outputs
```

3. Optionally start the API and trigger the run via HTTP:

```bash
uvicorn src.app:app --reload --port 8000
curl http://localhost:8000/run
```

4. Open `outputs/report_deck.pptx` in PowerPoint or compatible viewer to see the executive deck.
