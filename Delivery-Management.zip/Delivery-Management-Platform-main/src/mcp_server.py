from fastapi import FastAPI, HTTPException, Header, Request
from pydantic import BaseModel
from typing import Any, Dict, Optional
import yaml
import os
import json
from pathlib import Path

from poc_core import run_poc, fetch_issues_from_jira, normalize_issues, compute_metrics, evaluate_risks

APP_DIR = Path(__file__).resolve().parent.parent
TOOL_REG_PATH = APP_DIR / "config" / "mcp_tools.yaml"
CRED_PATH = APP_DIR / "config" / "sample_mcp_credentials.yaml"

app = FastAPI(title="POC MCP Server", version="0.1")


def load_tools() -> Dict[str, Any]:
    if TOOL_REG_PATH.exists():
        return yaml.safe_load(TOOL_REG_PATH.read_text()) or {}
    return {}


def load_credentials() -> Dict[str, Any]:
    if CRED_PATH.exists():
        return yaml.safe_load(CRED_PATH.read_text()) or {}
    return {}


TOOLS = load_tools()
CREDENTIALS = load_credentials()


class ExecuteRequest(BaseModel):
    tool: str
    input: Optional[Dict[str, Any]] = {}


def check_permission(api_key: Optional[str], tool_name: str) -> bool:
    if not api_key:
        return False
    creds = CREDENTIALS.get("api_keys", {})
    entry = creds.get(api_key)
    if not entry:
        return False
    allowed = entry.get("allowed_tools", [])
    if "*" in allowed:
        return True
    return tool_name in allowed


@app.get("/tools")
def list_tools():
    return {"tools": list(TOOLS.keys())}


@app.get("/tools/{tool_name}")
def get_tool(tool_name: str):
    t = TOOLS.get(tool_name)
    if not t:
        raise HTTPException(status_code=404, detail="tool not found")
    return t


@app.post("/execute")
async def execute(req: ExecuteRequest, x_api_key: Optional[str] = Header(None)):
    tool = TOOLS.get(req.tool)
    if not tool:
        raise HTTPException(status_code=404, detail="tool not found")

    if not check_permission(x_api_key, req.tool):
        raise HTTPException(status_code=403, detail="permission denied for this tool")

    try:
        # Map some common tools to local function calls
        if req.tool == "get_jira_release_metrics":
            cfg_path = req.input.get("config_path", "config/sample_project.yaml")
            # call run_poc with jira live fetch
            res = run_poc(cfg_path, data_path="jira", out_dir=req.input.get("out_dir", "outputs"), outputs={"excel": False, "pptx": False, "csv": False})
            return {"status": "ok", "result": res.get("metrics")}

        if req.tool == "generate_dashboard":
            cfg_path = req.input.get("config_path", "config/sample_project.yaml")
            out_dir = req.input.get("out_dir", "outputs")
            res = run_poc(cfg_path, data_path=req.input.get("data", "jira"), out_dir=out_dir, outputs={"excel": False, "pptx": True, "csv": False})
            return {"status": "ok", "result": {"pptx": res.get("pptx")}}

        if req.tool == "detect_blockers":
            cfg_path = req.input.get("config_path", "config/sample_project.yaml")
            # fetch issues and run detection logic used by poc_core
            cfg = yaml.safe_load(Path(cfg_path).read_text())
            data = fetch_issues_from_jira(cfg)
            df = normalize_issues(data)
            metrics = compute_metrics(df, cfg)
            risks, score = evaluate_risks(df, metrics, cfg)
            blockers = [r for r in risks if r.get("type") == "Blocker"]
            return {"status": "ok", "result": {"blockers": blockers, "risk_score": score}}

        if req.tool == "run_poc_full":
            cfg_path = req.input.get("config_path", "config/sample_project.yaml")
            out_dir = req.input.get("out_dir", "outputs")
            outputs = req.input.get("outputs")
            res = run_poc(cfg_path, data_path=req.input.get("data", "jira"), out_dir=out_dir, outputs=outputs)
            return {"status": "ok", "result": res}

        # default: no-op sandbox
        raise HTTPException(status_code=400, detail="tool not implemented in MCP server")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("MCP_PORT", 8080)))
