try:
    # Prefer relative import when running as a module (python -m src.run_poc)
    from .poc_core import run_poc
except Exception:
    # Fallback when running as a script from the `src` directory (python run_poc.py)
    from poc_core import run_poc
import argparse

def main():
    parser = argparse.ArgumentParser(description="Run POC starter kit")
    parser.add_argument("--config", default="config/sample_project.yaml")
    parser.add_argument("--data", default="sample_data/sample_jira.json")
    parser.add_argument("--out", default="outputs")
    args = parser.parse_args()
    res = run_poc(args.config, args.data, args.out)
    print("Outputs:\n", res)

if __name__ == "__main__":
    main()
