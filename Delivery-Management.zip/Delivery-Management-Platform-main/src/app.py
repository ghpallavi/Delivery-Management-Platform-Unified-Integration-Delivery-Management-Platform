from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
from .poc_core import run_poc

app = FastAPI(title="Delivery Management POC API", description="API for Delivery Management POC")

# Enable CORS for frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RunRequest(BaseModel):
    data_source: str = "sample"  # 'sample' or 'jira'
    generate_excel: bool = True
    generate_pptx: bool = True
    generate_csv: bool = True
    config: str = "config/sample_project.yaml"
    out_dir: str = "outputs"

@app.post("/api/run")
async def run_poc_api(request: RunRequest):
    """API endpoint to run POC with selected options"""
    try:
        # Determine data path based on source
        if request.data_source == "jira":
            data_path = "jira"
        else:
            data_path = "sample_data/sample_jira.json"
        
        # Run POC with selective output generation
        outputs = {
            "excel": request.generate_excel,
            "pptx": request.generate_pptx,
            "csv": request.generate_csv,
        }
        
        result = run_poc(request.config, data_path, request.out_dir, outputs)
        
        # Format response with file info
        files = {}
        if request.generate_excel and "excel" in result:
            files["excel"] = result["excel"]
        if request.generate_pptx and "pptx" in result:
            files["pptx"] = result["pptx"]
        if request.generate_csv and "csv" in result:
            files["csv"] = result["csv"]
        
        return {
            "success": True,
            "files": files,
            "metrics": result["metrics"],
            "risks": result["risks"],
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/download/{file_type}")
def download_file(file_type: str):
    """Download generated files"""
    file_map = {
        "excel": "outputs/report_metrics.xlsx",
        "pptx": "outputs/report_deck.pptx",
        "csv": "outputs/issues_normalized.csv",
    }
    
    if file_type not in file_map:
        raise HTTPException(status_code=404, detail="File type not found")
    
    file_path = file_map[file_type]
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found. Please run the POC first.")
    
    return FileResponse(
        path=file_path,
        filename=os.path.basename(file_path),
        media_type="application/octet-stream"
    )

@app.get("/api/health")
def health_check():
    """Health check endpoint"""
    return {"status": "ok"}


# Root route: serve built frontend index.html if present, otherwise return a helpful message
@app.get("/", response_class=HTMLResponse)
def root():
    build_index = os.path.join(os.path.dirname(__file__), "..", "frontend", "build", "index.html")
    # Resolve normalized path
    build_index = os.path.normpath(build_index)
    if os.path.exists(build_index):
        return FileResponse(build_index, media_type="text/html")
    return HTMLResponse(
        "<h1>Delivery Management POC</h1>"
        "<p>No frontend build found. Start the frontend with <code>npm start</code> (http://localhost:3000) or run <code>npm run build</code> and restart the backend.</p>",
        status_code=200,
    )

# Mount static files and serve React app
# In production, serve the built React app from frontend/build
# For development, the React app runs on a separate port
try:
    build_dir = os.path.join(os.path.dirname(__file__), "..", "frontend", "build")
    if os.path.exists(build_dir):
        app.mount("/", StaticFiles(directory=build_dir, html=True), name="static")
except:
    pass

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
