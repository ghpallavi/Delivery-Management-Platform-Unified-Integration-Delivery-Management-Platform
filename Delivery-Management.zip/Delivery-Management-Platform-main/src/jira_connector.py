import os
import base64
import requests
from typing import Optional, Dict, Any

class JiraClient:
    def __init__(self, base_url: str, username: Optional[str]=None, api_token: Optional[str]=None):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.api_token = api_token

    def _auth_header(self) -> Dict[str, str]:
        if self.api_token and self.username:
            token = f"{self.username}:{self.api_token}".encode("utf-8")
            b64 = base64.b64encode(token).decode("utf-8")
            return {"Authorization": f"Basic {b64}"}
        return {}

    def search_issues(self, jql: str, max_results: int = 100) -> Dict[str, Any]:
        url = f"{self.base_url}/rest/api/2/search"
        params = {"jql": jql, "maxResults": max_results}
        headers = {"Accept": "application/json"}
        headers.update(self._auth_header())
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def fetch_project_issues(self, project_key: str, max_results: int = 500):
        jql = f"project = {project_key} ORDER BY created DESC"
        return self.search_issues(jql, max_results=max_results)

def make_client_from_config(cfg: dict) -> Optional[JiraClient]:
    jira_cfg = cfg.get("jira") or {}
    base = jira_cfg.get("base_url") or os.getenv("JIRA_BASE_URL")
    user = jira_cfg.get("username") or os.getenv("JIRA_USER")
    token = jira_cfg.get("api_token") or os.getenv("JIRA_API_TOKEN")
    if base:
        return JiraClient(base, username=user, api_token=token)
    return None
