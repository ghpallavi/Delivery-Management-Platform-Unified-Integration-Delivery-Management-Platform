import os
import json
import yaml
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

from pptx import Presentation
from pptx.util import Inches, Pt

from .jira_connector import make_client_from_config

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def load_sample_data(path):
    with open(path, "r") as f:
        return json.load(f)

def fetch_issues_from_jira(cfg):
    client = make_client_from_config(cfg)
    if client is None:
        raise ValueError("Jira configuration not found in config or environment")
    proj = cfg.get("project_space", {}).get("jira_project")
    raw = client.fetch_project_issues(proj, max_results=500)
    issues = []
    for it in raw.get("issues", []):
        fields = it.get("fields", {})
        issues.append({
            "id": it.get("id"),
            "key": it.get("key"),
            "type": fields.get("issuetype", {}).get("name"),
            "summary": fields.get("summary"),
            "status": fields.get("status", {}).get("name"),
            "assignee": (fields.get("assignee") or {}).get("displayName"),
            "fixVersion": ",".join([v.get("name") for v in (fields.get("fixVersions") or [])]) if fields.get("fixVersions") else None,
            "labels": fields.get("labels", []),
            "created": fields.get("created"),
            "updated": fields.get("updated"),
            "story_points": fields.get("customfield_10016") or fields.get("customfield_10002") or 0,
            "epic": (fields.get("epic") if fields.get("epic") else fields.get("customfield_10008")),
            "links": [],
        })
    return {"issues": issues}

def normalize_issues(data):
    records = []
    for issue in data.get("issues", []):
        rec = {
            "id": issue.get("id"),
            "key": issue.get("key"),
            "type": issue.get("type"),
            "summary": issue.get("summary"),
            "status": issue.get("status"),
            "assignee": issue.get("assignee"),
            "fixVersion": issue.get("fixVersion"),
            "labels": ",".join(issue.get("labels", [])),
            "created": issue.get("created"),
            "updated": issue.get("updated"),
            "story_points": issue.get("story_points", 0),
            "epic": issue.get("epic"),
            "links": issue.get("links", []),
        }
        records.append(rec)
    df = pd.DataFrame.from_records(records)
    if not df.empty:
        df["created"] = pd.to_datetime(df["created"])
        df["updated"] = pd.to_datetime(df["updated"])
    return df

def compute_metrics(df, config):
    metrics = {}
    if df.empty:
        return metrics

    current_sprint = config.get("project_space", {}).get("sprint", "current")
    total_sp = df["story_points"].sum()
    done_sp = df.loc[df["status"].str.lower() == "done", "story_points"].sum()
    metrics["sprint_completion_pct"] = round((done_sp / total_sp * 100) if total_sp > 0 else 0, 1)

    # Epic progress
    epic_groups = df.groupby("epic") if "epic" in df.columns else None
    epic_progress = {}
    if epic_groups is not None:
        for epic, g in epic_groups:
            total = g["story_points"].sum()
            done = g.loc[g["status"].str.lower() == "done", "story_points"].sum()
            epic_progress[epic or "<no-epic>"] = {
                "total_sp": int(total),
                "done_sp": int(done),
                "pct": round((done / total * 100) if total > 0 else 0, 1),
            }
    metrics["epic_progress"] = epic_progress

    # Blocker count
    blockers = df[df["labels"].str.contains("blocker", case=False, na=False) | (df["status"].str.lower() == "blocked")]
    metrics["blocker_count"] = int(len(blockers))

    # Defect aging (for issues of type Bug)
    bugs = df[df["type"].str.lower() == "bug"]
    if not bugs.empty:
        bugs["age_days"] = (pd.Timestamp.now(tz='UTC') - bugs["created"]).dt.days
        metrics["avg_bug_age_days"] = float(bugs["age_days"].mean())
        metrics["open_bug_count"] = int(len(bugs[bugs["status"].str.lower() != "done"]))
    else:
        metrics["avg_bug_age_days"] = 0
        metrics["open_bug_count"] = 0

    # Spillover simple metric: percent of issues in progress but not done
    in_progress = df[~df["status"].str.lower().isin(["done", "closed"]) ]
    metrics["spillover_pct"] = round((len(in_progress) / len(df) * 100) if len(df) > 0 else 0, 1)

    return metrics

def evaluate_risks(df, metrics, config):
    risks = []
    rules = config.get("project_space", {}).get("risk_rules", {})
    blocker_days = rules.get("blocker_days", 3)

    # Blocker aging
    blockers = df[df["labels"].str.contains("blocker", case=False, na=False) | (df["status"].str.lower() == "blocked")]
    for _, b in blockers.iterrows():
        age = (pd.Timestamp.now(tz='UTC') - b["created"]).days if pd.notnull(b["created"]) else 0
        level = "MEDIUM"
        if age >= blocker_days:
            level = "HIGH"
        risks.append({
            "key": b.get("key"),
            "summary": b.get("summary"),
            "type": "Blocker",
            "age_days": int(age),
            "risk": level,
        })

    # Spillover rule
    spill_pct = metrics.get("spillover_pct", 0)
    if spill_pct > 20:
        risks.append({"key": "SPILLOVER", "summary": f"Spillover {spill_pct}% exceeds threshold", "risk": "MEDIUM"})

    # Reopened bugs placeholder (would require historical data)
    # Quality rule example
    if metrics.get("open_bug_count", 0) > 10:
        risks.append({"key": "BUGS", "summary": "High open bug count", "risk": "MEDIUM"})

    # Overall score (simple heuristic)
    score = 100
    for r in risks:
        if r.get("risk") == "HIGH":
            score -= 30
        elif r.get("risk") == "MEDIUM":
            score -= 10
    score = max(0, score)

    return risks, score

def generate_excel(metrics, df, out_path):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    writer = pd.ExcelWriter(out_path, engine="openpyxl")
    # Metrics sheet
    pd.DataFrame([metrics]).to_excel(writer, sheet_name="metrics", index=False)
    # Epic progress
    epic_df = pd.DataFrame.from_dict(metrics.get("epic_progress", {}), orient="index").reset_index()
    epic_df.rename(columns={"index": "epic"}, inplace=True)
    epic_df.to_excel(writer, sheet_name="epics", index=False)
    # Normalized issues
    if not df.empty:
        # Convert timezone-aware datetime columns to naive for Excel compatibility
        df_excel = df.copy()
        for col in df_excel.columns:
            if hasattr(df_excel[col].dtype, 'tz') and df_excel[col].dtype.tz is not None:
                df_excel[col] = df_excel[col].dt.tz_localize(None)
        df_excel.to_excel(writer, sheet_name="issues", index=False)
    writer.close()

def generate_pptx(metrics, risks, out_path):
    from pptx.util import Inches, Pt
    prs = Presentation()
    # Title slide
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    title = slide.shapes.title
    title.text = "Automated Delivery Review"
    # Try to set subtitle if it exists
    if len(slide.placeholders) > 1:
        try:
            subtitle = slide.placeholders[1]
            subtitle.text = f"Generated: {datetime.utcnow().isoformat()}"
        except (KeyError, IndexError):
            pass

    # KPI slide
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    title = slide.shapes.title
    title.text = "Key Metrics"
    # Add content with safe placeholder access
    if len(slide.placeholders) > 1:
        try:
            body = slide.placeholders[1].text_frame
            body.text = f"Sprint completion: {metrics.get('sprint_completion_pct', 0)}%"
            p = body.add_paragraph()
            p.text = f"Blockers: {metrics.get('blocker_count', 0)}"
            p.level = 1
            p = body.add_paragraph()
            p.text = f"Spillover: {metrics.get('spillover_pct', 0)}%"
            p.level = 1
        except (KeyError, IndexError):
            pass

    # Risk slide
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = "Risks"
    if len(slide.placeholders) > 1:
        try:
            body = slide.placeholders[1].text_frame
            if not risks:
                body.text = "No immediate risks detected."
            else:
                first = True
                for r in risks:
                    if first:
                        body.text = f"{r.get('risk')}: {r.get('key')} - {r.get('summary')}"
                        first = False
                    else:
                        p = body.add_paragraph()
                        p.text = f"{r.get('risk')}: {r.get('key')} - {r.get('summary')}"
                        p.level = 1
        except (KeyError, IndexError):
            pass

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    # Epic progress chart
    epic_progress = metrics.get("epic_progress", {})
    if epic_progress:
        epics = list(epic_progress.keys())
        pct = [epic_progress[e]["pct"] for e in epics]
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.bar(epics, pct, color="#2c7fb8")
        ax.set_ylim(0, 100)
        ax.set_ylabel("% complete")
        ax.set_title("Epic progress")
        plt.xticks(rotation=30, ha="right")
        chart_path = os.path.join(".", out_path if os.path.isdir(out_path) else os.path.dirname(out_path), "epic_progress.png")
        # ensure directory
        chart_dir = os.path.dirname(chart_path) or "."
        os.makedirs(chart_dir, exist_ok=True)
        fig.tight_layout()
        fig.savefig(chart_path)
        plt.close(fig)

        # add slide with chart image
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = "Epic Progress"
        left = Inches(1)
        top = Inches(1.5)
        slide.shapes.add_picture(chart_path, left, top, width=Inches(8))

    prs.save(out_path)

def run_poc(config_path, data_path, out_dir="outputs", outputs=None):
    """
    Run POC with selective output generation.
    
    Args:
        config_path: Path to config YAML
        data_path: Path to sample JSON or 'jira' for live fetch
        out_dir: Output directory
        outputs: Dict with keys 'excel', 'pptx', 'csv' (bool) to control what to generate
                If None, generates all
    """
    cfg = load_config(config_path)
    # if data_path is 'jira' or None and config contains jira connection, fetch live
    if (data_path is None or data_path == "jira") and cfg.get("jira"):
        data = fetch_issues_from_jira(cfg)
    else:
        data = load_sample_data(data_path)
    df = normalize_issues(data)
    metrics = compute_metrics(df, cfg)
    risks, score = evaluate_risks(df, metrics, cfg)
    metrics["delivery_confidence_score"] = score

    # Default: generate all outputs
    if outputs is None:
        outputs = {"excel": True, "pptx": True, "csv": True}

    result = {"metrics": metrics, "risks": risks}
    
    # Conditional output generation
    if outputs.get("excel", True):
        excel_path = os.path.join(out_dir, "report_metrics.xlsx")
        generate_excel(metrics, df, excel_path)
        result["excel"] = excel_path
    
    if outputs.get("pptx", True):
        pptx_path = os.path.join(out_dir, "report_deck.pptx")
        generate_pptx(metrics, risks, pptx_path)
        result["pptx"] = pptx_path
    
    if outputs.get("csv", True):
        csv_path = os.path.join(out_dir, "issues_normalized.csv")
        if not df.empty:
            os.makedirs(out_dir, exist_ok=True)
            df.to_csv(csv_path, index=False)
        result["csv"] = csv_path

    return result

if __name__ == "__main__":
    # quick local run
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/sample_project.yaml")
    parser.add_argument("--data", default="sample_data/sample_jira.json")
    parser.add_argument("--out", default="outputs")
    args = parser.parse_args()
    res = run_poc(args.config, args.data, args.out)
    print("Generated:", res)
