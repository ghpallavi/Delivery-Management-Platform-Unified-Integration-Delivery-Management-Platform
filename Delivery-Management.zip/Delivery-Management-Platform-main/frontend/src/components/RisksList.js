import React from 'react';
import './RisksList.css';

function RisksList({ risks }) {
  return (
    <section className="results-section risks-section">
      <h3>⚠️ Identified Risks</h3>
      <div className="risks-list">
        {risks.map((risk, index) => (
          <div key={index} className={`risk-item risk-${risk.risk.toLowerCase()}`}>
            <div className="risk-header">
              <span className="risk-level">{risk.risk}</span>
              <span className="risk-key">{risk.key}</span>
            </div>
            <div className="risk-summary">{risk.summary}</div>
            {risk.age_days && (
              <div className="risk-details">
                Age: {risk.age_days} day{risk.age_days !== 1 ? 's' : ''}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

export default RisksList;
