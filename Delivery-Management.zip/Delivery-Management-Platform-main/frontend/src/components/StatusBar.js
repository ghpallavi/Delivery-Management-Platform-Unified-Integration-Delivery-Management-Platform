import React from 'react';
import './StatusBar.css';

function StatusBar() {
  return (
    <div className="status-bar">
      <div className="spinner"></div>
      <span className="status-text">Processing your request...</span>
    </div>
  );
}

export default StatusBar;
