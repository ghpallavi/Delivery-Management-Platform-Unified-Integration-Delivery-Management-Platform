import React from 'react';
import './LifecycleNav.css';

function LifecycleNav({ stage, onChange }) {
  const stages = ['Planning', 'Execution', 'Release'];

  return (
    <nav className="lifecycle-nav">
      {stages.map(s => (
        <button
          key={s}
          className={`lifecycle-btn ${s === stage ? 'active' : ''}`}
          onClick={() => onChange(s)}
        >
          {s}
        </button>
      ))}
    </nav>
  );
}

export default LifecycleNav;
