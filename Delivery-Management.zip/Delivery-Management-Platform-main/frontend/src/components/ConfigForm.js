import React, { useState } from 'react';
import './ConfigForm.css';

function ConfigForm({ onSubmit, disabled }) {
  const [formData, setFormData] = useState({
    data_source: 'sample',
    generate_excel: true,
    generate_pptx: true,
    generate_csv: true,
    config: 'config/sample_project.yaml',
    out_dir: 'outputs',
  });

  const handleChange = (e) => {
    const { name, type, checked, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleReset = () => {
    setFormData({
      data_source: 'sample',
      generate_excel: true,
      generate_pptx: true,
      generate_csv: true,
      config: 'config/sample_project.yaml',
      out_dir: 'outputs',
    });
  };

  return (
    <div className="config-form">
      <form onSubmit={handleSubmit}>
        {/* Data Source Section */}
        <section className="form-section">
          <h3>📊 Data Source</h3>
          <div className="form-group">
            <label htmlFor="data_source">Select Data Source</label>
            <select
              id="data_source"
              name="data_source"
              value={formData.data_source}
              onChange={handleChange}
              disabled={disabled}
            >
              <option value="sample">Sample Data (JSON)</option>
              <option value="jira">Live Jira Feed</option>
            </select>
          </div>
          {formData.data_source === 'jira' && (
            <p className="info-text">
              ℹ️ Make sure JIRA_BASE_URL, JIRA_USER, and JIRA_API_TOKEN are set in .env
            </p>
          )}
        </section>

        {/* Output Selection Section */}
        <section className="form-section">
          <h3>📁 Select Outputs to Generate</h3>
          <div className="checkbox-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="generate_excel"
                checked={formData.generate_excel}
                onChange={handleChange}
                disabled={disabled}
              />
              <span>📊 Excel Report</span>
            </label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="generate_pptx"
                checked={formData.generate_pptx}
                onChange={handleChange}
                disabled={disabled}
              />
              <span>🎯 PowerPoint Deck</span>
            </label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="generate_csv"
                checked={formData.generate_csv}
                onChange={handleChange}
                disabled={disabled}
              />
              <span>📋 CSV Export</span>
            </label>
          </div>
        </section>

        {/* Configuration Section */}
        <section className="form-section">
          <h3>⚙️ Configuration</h3>
          <div className="form-group">
            <label htmlFor="config">Config File Path</label>
            <input
              type="text"
              id="config"
              name="config"
              value={formData.config}
              onChange={handleChange}
              disabled={disabled}
            />
          </div>
          <div className="form-group">
            <label htmlFor="out_dir">Output Directory</label>
            <input
              type="text"
              id="out_dir"
              name="out_dir"
              value={formData.out_dir}
              onChange={handleChange}
              disabled={disabled}
            />
          </div>
        </section>

        {/* Action Buttons */}
        <div className="button-group">
          <button
            type="submit"
            className="btn btn-primary"
            disabled={disabled}
          >
            {disabled ? 'Running...' : 'Run POC'}
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleReset}
            disabled={disabled}
          >
            Reset Form
          </button>
        </div>
      </form>
    </div>
  );
}

export default ConfigForm;
