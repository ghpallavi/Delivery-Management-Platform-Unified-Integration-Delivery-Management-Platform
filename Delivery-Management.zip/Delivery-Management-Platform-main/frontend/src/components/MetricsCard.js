import React from 'react';
import './MetricsCard.css';

function MetricsCard({ label, value, unit, type = 'default' }) {
  const getColorClass = () => {
    if (type === 'score' || type === 'percentage') {
      const numValue = parseFloat(value);
      if (numValue >= 70) return 'success';
      if (numValue >= 50) return 'warning';
      return 'danger';
    }
    return type;
  };

  const colorClass = getColorClass();

  return (
    <div className={`metric-card metric-${colorClass}`}>
      <div className="metric-label">{label}</div>
      <div className="metric-value">
        {value}{unit}
      </div>
    </div>
  );
}

export default MetricsCard;
