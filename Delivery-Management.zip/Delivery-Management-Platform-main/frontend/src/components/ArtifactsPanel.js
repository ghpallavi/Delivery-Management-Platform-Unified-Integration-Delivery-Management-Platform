import React from 'react';
import './ArtifactsPanel.css';
import FilesList from './FilesList';

function ArtifactsPanel({ stage, data }) {
  if (stage === 'Planning') {
    return (
      <section className="artifacts-panel planning-artifacts">
        <h3>Artifacts (Planning)</h3>
        <p>Planned artifacts: config file, expected outputs, report templates.</p>
      </section>
    );
  }

  if (stage === 'Execution') {
    return (
      <section className="artifacts-panel execution-artifacts">
        <h3>Artifacts (Execution)</h3>
        <p>Artifacts are being generated. Check back when execution completes.</p>
      </section>
    );
  }

  // Release
  return (
    <section className="artifacts-panel release-artifacts">
      <h3>Artifacts (Release)</h3>
      {data && data.files && Object.keys(data.files).length > 0 ? (
        <FilesList files={data.files} />
      ) : (
        <p>No generated files available.</p>
      )}
    </section>
  );
}

export default ArtifactsPanel;
