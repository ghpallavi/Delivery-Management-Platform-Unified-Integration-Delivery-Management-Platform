import React from 'react';
import './FilesList.css';

function FilesList({ files }) {
  const fileIcons = {
    excel: '📊',
    pptx: '🎯',
    csv: '📋',
  };

  const fileLabels = {
    excel: 'Excel Report',
    pptx: 'PowerPoint Deck',
    csv: 'CSV Export',
  };

  return (
    <section className="results-section files-section">
      <h3>📁 Generated Files</h3>
      <div className="files-list">
        {Object.entries(files).map(([type, path]) => (
          <div key={type} className="file-item">
            <div className="file-info">
              <span className="file-icon">{fileIcons[type]}</span>
              <div className="file-details">
                <div className="file-name">{path.split('/').pop()}</div>
                <div className="file-path">{path}</div>
              </div>
            </div>
            <a href={`/api/download/${type}`} className="download-btn" download>
              ⬇️ Download
            </a>
          </div>
        ))}
      </div>
    </section>
  );
}

export default FilesList;
