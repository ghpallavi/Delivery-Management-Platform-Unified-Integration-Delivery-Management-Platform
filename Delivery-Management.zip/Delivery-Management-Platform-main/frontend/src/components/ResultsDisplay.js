import React from 'react';
import './ResultsDisplay.css';
import MetricsCard from './MetricsCard';
import FilesList from './FilesList';
import RisksList from './RisksList';

function ResultsDisplay({ data }) {
  return (
    <div className="results-display">
      <div className="results-header">
        <h2>✅ Generation Complete</h2>
      </div>

      {/* Files Section */}
      {data.files && Object.keys(data.files).length > 0 && (
        <FilesList files={data.files} />
      )}

      {/* Metrics Section */}
      {data.metrics && (
        <section className="results-section">
          <h3>📊 Key Metrics</h3>
          <div className="metrics-grid">
            <MetricsCard
              label="Delivery Confidence"
              value={data.metrics.delivery_confidence_score}
              unit="%"
              type="score"
            />
            <MetricsCard
              label="Sprint Completion"
              value={(data.metrics.sprint_completion_pct || 0).toFixed(1)}
              unit="%"
              type="percentage"
            />
            <MetricsCard
              label="Blockers"
              value={data.metrics.blocker_count || 0}
              type={data.metrics.blocker_count > 0 ? 'danger' : 'success'}
            />
            <MetricsCard
              label="Open Bugs"
              value={data.metrics.open_bug_count || 0}
              type={data.metrics.open_bug_count > 0 ? 'warning' : 'success'}
            />
            <MetricsCard
              label="Avg Bug Age"
              value={(data.metrics.avg_bug_age_days || 0).toFixed(1)}
              unit="days"
              type="info"
            />
            <MetricsCard
              label="Spillover"
              value={(data.metrics.spillover_pct || 0).toFixed(1)}
              unit="%"
              type={(data.metrics.spillover_pct || 0) > 50 ? 'danger' : 'success'}
            />
          </div>

          {/* Epic Progress */}
          {data.metrics.epic_progress && Object.keys(data.metrics.epic_progress).length > 0 && (
            <div className="epic-progress">
              <h4>Epic Progress</h4>
              <div className="epics-list">
                {Object.entries(data.metrics.epic_progress).map(([epic, progress]) => (
                  <div key={epic} className="epic-item">
                    <div className="epic-info">
                      <span className="epic-name">{epic}</span>
                      <span className="epic-percentage">{progress.pct.toFixed(1)}%</span>
                    </div>
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{ width: `${progress.pct}%` }}
                      ></div>
                    </div>
                    <div className="epic-details">
                      {progress.done_sp}/{progress.total_sp} story points
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {/* Risks Section */}
      {data.risks && data.risks.length > 0 && (
        <RisksList risks={data.risks} />
      )}

      {/* No Risks Alert */}
      {data.risks && data.risks.length === 0 && (
        <section className="results-section">
          <div className="success-alert">
            <span>✨ No immediate risks detected</span>
          </div>
        </section>
      )}
    </div>
  );
}

export default ResultsDisplay;
