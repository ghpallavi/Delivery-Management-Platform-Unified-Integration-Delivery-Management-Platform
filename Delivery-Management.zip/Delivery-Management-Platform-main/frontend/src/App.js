import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
import ConfigForm from './components/ConfigForm';
import ResultsDisplay from './components/ResultsDisplay';
import StatusBar from './components/StatusBar';
import LifecycleNav from './components/LifecycleNav';
import ArtifactsPanel from './components/ArtifactsPanel';

function App() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleRun = async (config) => {
    setLoading(true);
    setError(null);
    setResult(null);
    setStage('Execution');

    try {
      const response = await axios.post('/api/run', config);
      setResult(response.data);
      setStage('Release');
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const [stage, setStage] = useState('Planning');

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <h1>📊 Delivery Management Platform</h1>
          <p>Generate automated delivery reports and risk analysis</p>
        </div>
      </header>

      <main className="app-main">
        <div className="container">
          <LifecycleNav stage={stage} onChange={setStage} />

          {/* Planning Stage */}
          {stage === 'Planning' && (
            <div className="stage-panel planning-panel">
              <h2>Planning</h2>
              <ConfigForm onSubmit={handleRun} disabled={loading} />
              <ArtifactsPanel stage="Planning" data={result} />
            </div>
          )}

          {/* Execution Stage */}
          {stage === 'Execution' && (
            <div className="stage-panel execution-panel">
              <h2>Execution</h2>
              <StatusBar />
              <p>Running generation — artifacts will appear when ready.</p>
            </div>
          )}

          {/* Release Stage */}
          {stage === 'Release' && (
            <div className="stage-panel release-panel">
              <h2>Release</h2>
              {error && (
                <div className="error-box">
                  <h4>❌ Error</h4>
                  <p>{error}</p>
                </div>
              )}
              {result ? (
                <>
                  <ResultsDisplay data={result} />
                  <ArtifactsPanel stage="Release" data={result} />
                </>
              ) : (
                <p>No release artifacts available yet.</p>
              )}
            </div>
          )}
        </div>
      </main>

      <footer className="app-footer">
        <p>Delivery Management Platform © 2024</p>
      </footer>
    </div>
  );
}

export default App;
