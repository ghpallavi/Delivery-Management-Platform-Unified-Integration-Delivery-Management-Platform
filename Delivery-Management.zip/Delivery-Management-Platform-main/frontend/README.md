# Delivery Management Platform - React Frontend

This is a modern React-based UI for the Delivery Management Platform, providing an interactive interface for running POC analysis and generating delivery reports.

## Features

- **Easy Form Interface**: Select data source, outputs, and configuration parameters
- **Real-time Status Updates**: Track processing with loading indicators
- **Results Dashboard**: View metrics, risks, and download generated reports
- **Responsive Design**: Works on desktop and mobile devices
- **Modern UI**: Beautiful gradient designs and card-based layouts

## Development Setup

### Prerequisites
- Node.js 14+ and npm

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

The app will open at `http://localhost:3000`

### Development Commands

- `npm start` - Run development server
- `npm build` - Build production bundle
- `npm test` - Run tests

## API Integration

The frontend communicates with the FastAPI backend at `http://localhost:8000` (configured via the `proxy` setting in package.json).

### API Endpoints Used

- `POST /api/run` - Run POC with selected options
- `GET /api/download/{type}` - Download generated files (excel, pptx, csv)
- `GET /api/health` - Health check

### Proxying in Development

During development, API requests are automatically proxied to `http://localhost:8000` as configured in package.json.

## Component Structure

```
src/
├── App.js                 # Main application component
├── App.css
├── index.js              # Entry point
├── index.css             # Global styles
└── components/
    ├── ConfigForm.js     # Configuration form
    ├── ConfigForm.css
    ├── ResultsDisplay.js # Results view
    ├── ResultsDisplay.css
    ├── MetricsCard.js    # Individual metric card
    ├── MetricsCard.css
    ├── FilesList.js      # File downloads section
    ├── FilesList.css
    ├── RisksList.js      # Risks display
    ├── RisksList.css
    ├── StatusBar.js      # Loading indicator
    └── StatusBar.css
```

## Production Build

To build for production:

```bash
npm run build
```

The build folder will be created with optimized production files. These can be served by the FastAPI backend from `/build`.

## Styling

The project uses CSS modules and custom styling with:
- CSS Grid and Flexbox for layouts
- CSS Variables for theming (can be added)
- Responsive design with media queries
- Smooth animations and transitions

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
