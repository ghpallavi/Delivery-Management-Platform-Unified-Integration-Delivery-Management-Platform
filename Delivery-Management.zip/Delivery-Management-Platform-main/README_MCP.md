MCP Server (POC)
=================

This folder adds a minimal Model Context Protocol (MCP) server for the Delivery Management POC.

Files:
- `src/mcp_server.py`: FastAPI MCP server exposing a tool registry and execute endpoint.
- `config/mcp_tools.yaml`: Tool registry and simple schemas.
- `config/sample_mcp_credentials.yaml`: Example API keys and allowed tool lists.

Run locally (dev):

```bash
# from workspace root
pip install -r requirements.txt
uvicorn src.mcp_server:app --reload --port 8080
```

Example call (list tools):

```bash
curl -s http://localhost:8080/tools | jq
```

Execute a tool (example):

```bash
curl -s -X POST http://localhost:8080/execute \
  -H "Content-Type: application/json" \
  -H "X-API-KEY: dev-token" \
  -d '{"tool":"get_jira_release_metrics","input":{"config_path":"config/sample_project.yaml"}}' | jq
```

Notes:
- This is a minimal POC scaffold. Add stronger auth, auditing, and per-tenant namespaces for production.
